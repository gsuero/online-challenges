package com.hubspot.garis.model;

import java.util.ArrayList;

public class PartnerList extends ArrayList<Partner> {
    private static final long serialVersionUID = 3057746624965935512L;

}
